import React from 'react';

const DeleteTask = ({ onDelete, onCancel }) => {
  return (
    <div id="delete-view">
      <h2>Delete Task</h2>
      <p>Are you sure you want to delete this task?</p>
      <button className="btn btn-danger" onClick={onDelete}>
        Yes, Delete
      </button>
      <button className="btn btn-secondary ml-2" onClick={onCancel}>
        Cancel
      </button>
    </div>
  );
};

export default DeleteTask;
