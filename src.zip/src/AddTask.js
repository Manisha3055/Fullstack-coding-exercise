import React, { useState } from 'react';

function AddTask({ onSave }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleSave = () => {
    onSave({ title, description });
    setTitle('');
    setDescription('');
  };

  return (
    <div id="add-view">
      <h2>Add Task</h2>
      <form>
        <div className="form-group">
          <label htmlFor="task-title">Task Title:</label>
          <input type="text" className="form-control" id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="form-group">
          <label htmlFor="task-description">Task Description:</label>
          <textarea className="form-control" id="task-description" value={description} onChange={(e) => setDescription(e.target.value)} rows="3"></textarea>
        </div>
        <button type="button" className="btn btn-primary" onClick={handleSave}>
          Add Task
        </button>
      </form>
    </div>
  );
}

export default AddTask;
