import logo from './logo.svg';
import './App.css';
import Assignment from './Assignment'
import LoginForm from './Login';

function App() {
  return (
    <div>

      <Assignment />
      
    </div>
  );
}

export default App;
