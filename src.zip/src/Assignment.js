import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import LoginForm from './Login';
import RegisterForm from './Register';
import AddTask from './AddTask';
import DeleteTask from './DeleteTask';

const tasksData = [
  { id: 1, title: "Task 1", description: "Description for Task 1" },
  { id: 2, title: "Task 2", description: "Description for Task 2" },
  { id:3, title: "Task3", description: "Description for Task3" },
  
];

function TaskList({ tasks, onItemClick, onEditClick }) {
  return (
    <div id="list-view">
      <h2>Task List</h2>
      <ul className="list-group">
        {tasks.map(task => (
          <li key={task.id} className="list-group-item task-list-item">
            <span onClick={() => onItemClick(task.id)}>{task.title}</span>
            <button className="btn btn-warning btn-sm float-right" onClick={() => onEditClick(task.id)}>
              Edit
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
function TaskDetails({ task, onDelete }) {
  return (
    <div id="details-view">
      <h2>Task Details</h2>
      <p>Title: {task.title}</p>
      <p>Description: {task.description}</p>
      <button className="btn btn-danger" onClick={onDelete}>Delete Task</button>
    </div>
  );
}

function EditTask({ taskToEdit, onSave }) {
  const [title, setTitle] = useState(taskToEdit ? taskToEdit.title : '');
  const [description, setDescription] = useState(taskToEdit ? taskToEdit.description : '');

  const handleSave = () => {
    onSave({ title, description });
    setTitle('');
    setDescription('');
  };

   return (
    <div id="edit-view">
      <h2>Edit Task</h2>
      <form>
        <div className="form-group">
          <label htmlFor="task-title">Task Title:</label>
          <input type="text" className="form-control" id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="form-group">
          <label htmlFor="task-description">Task Description:</label>
          <textarea className="form-control" id="task-description" value={description} onChange={(e) => setDescription(e.target.value)} rows="3"></textarea>
        </div>
        <button type="button" className="btn btn-primary" onClick={handleSave}>
          Update Task
        </button>
      </form>
    </div>
  );
}


function AddEditTask({ taskToEdit, onSave }) {
  const [title, setTitle] = useState(taskToEdit ? taskToEdit.title : '');
  const [description, setDescription] = useState(taskToEdit ? taskToEdit.description : '');

  const handleSave = () => {
    onSave({ title, description });
    setTitle('');
    setDescription('');
  };


  return (
    <div id="add-edit-view">
      <h2>{taskToEdit ? 'Edit Task' : 'Add Task'}</h2>
      <form>
        <div className="form-group">
          <label htmlFor="task-title">Task Title:</label>
          <input type="text" className="form-control" id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="form-group">
          <label htmlFor="task-description">Task Description:</label>
          <textarea className="form-control" id="task-description" value={description} onChange={(e) => setDescription(e.target.value)} rows="3"></textarea>
        </div>
        <button type="button" className="btn btn-primary" onClick={handleSave}>
          {taskToEdit ? 'Update Task' : 'Save Task'}
        </button>
      </form>
    </div>
  );
}

function App() {
  const [tasks, setTasks] = useState(tasksData);
  const [selectedTask, setSelectedTask] = useState(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [showDeleteConfirmation, setShowDeleteConfirmation] = useState(false);
  const [isTaskListPage, setIsTaskListPage] = useState(true);
  
  const showDetailsView = (taskId) => {
    const task = tasks.find(t => t.id === taskId);
    setSelectedTask(task);
  };

  const deleteTask = () => {
    setShowDeleteConfirmation(true);
  };

  const confirmDelete = () => {
    setTasks(tasks.filter((task) => task !== selectedTask));
    setSelectedTask(null);
    setShowDeleteConfirmation(false);
  };

  const cancelDelete = () => {
    setShowDeleteConfirmation(false);
  };

  const saveTask = (newTask) => {
    if (editTask) {
      setTasks(tasks.map(task => (task === editTask ? { ...task, ...newTask } : task)));
      setEditTask(null);
    } else {
      setTasks([...tasks, { ...newTask, id: tasks.length + 1 }]);
    }
    setSelectedTask(null);
  };

  const showListView = () => {
    setSelectedTask(null);
    setEditTask(null);
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
  };

  const handleRegister = () => {
    setIsRegistered(true);
  };

  const handleEditClick = (taskId) => {
    const taskToEdit = tasks.find(t => t.id === taskId);
    setEditTask(taskToEdit);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <div className="container mt-4">
      {!isRegistered ? (
        <RegisterForm onRegister={handleRegister} />
      ) : (
        <>
          {isLoggedIn ? (
            <>
              {selectedTask ? (
                showDeleteConfirmation ? (
                  <DeleteTask onDelete={confirmDelete} onCancel={cancelDelete} />
                ) : (
                  <TaskDetails task={selectedTask} onDelete={deleteTask} />
                )
              ) : (
                editTask ? (
                  <EditTask taskToEdit={editTask} onSave={saveTask} />
                ) : (
                  <>
                    <TaskList tasks={tasks} onItemClick={showDetailsView} onEditClick={handleEditClick} />
                    <AddTask onSave={saveTask} />
                  </>
                )
              )}
              <button className="btn btn-secondary" onClick={handleLogout}>Logout</button>
            </>
          ) : (
            <LoginForm onLogin={handleLogin} />
          )}
        </>
      )}
    </div>
  );
}

export default App;